﻿ECEN 5273
Programming assignment 1

The purpose of this assignment:
1. Transferring file between a client and a server using socket using UDP.
2. Implement reliability protocol for reliable transfer of files remotely without packet loss.

How to compile the program:
Both the client and server have a Makefile.
make clean    –-> Delete all the executables
make all          –-> Compile the code and create the executables
Then you can execute the the server by running,
                          ./server <port number>
execute client by running,
                          ./client <ip address of server> <port number>


The commands implemented in this assignment are:
1. get <filename>: The server transmits the requested file to the client
2. put <filename>:  The server receives the transmitted file by the client and stores it
     locally
3. ls: The server searchs all the files it has in its local directory and send a list of
     all these files to the client.
4. delete: The server delete file if it exists. Otherwise do nothing.
5. exit: The server exits gracefully.

Within the main() of the server and client, we create a socket, bind them to a address and then in server, it keeps on listening for command from client. 
The client and server run in a loop continuously. So, the client waits for the user to enter an appropriate command and sends it to the server and waits for server to complete the request and waits for an appropriate message from the server. In both nodes, whenever any data or acknowledgment is sent (using sendto()) on the other side data is received using recvfrom(). A timeout of 1sec is implemented using setsockopt(), if recvfrom() doesn’t receive anything and re-receives the data or acknowledgment until anything is received.
